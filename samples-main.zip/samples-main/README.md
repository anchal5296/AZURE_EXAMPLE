# Samples

Samples for ASP.NET and ASP.NET Core.

ASP.NET samples are under the [samples/aspnet](samples/aspnet) directory.

ASP.NET Core samples are under the [samples/aspnetcore](samples/aspnetcore) directory.
